import React from 'react'

function Footer() {
  return (
    <div>
        <div class="footer">
    <div class="copyright">
        <p>Copyright &copy; Developed by <a href="#">SportSpark</a> 2024</p>
    </div>
</div>
</div>
  )
}

export default Footer;